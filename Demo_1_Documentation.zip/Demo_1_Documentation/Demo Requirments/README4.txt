﻿Below are the steps to call to either the Parks or Alerts NPS API’s.


Step 1: Have the base link: 
https://developer.nps.gov/api/v1/alerts


Step 2: Use the unique API Key and include it in the call separated by a “?”:
https://developer.nps.gov/api/v1/parks?api_key=UM1h28u00KVzbF5neRU0YLzt3Cb48nCf1PTBJWvJ


Step 3: Have any additional parameters separated by an “&”, for example, let's use the parameter 
“statecode”, and the value of it as “nj”:
https://developer.nps.gov/api/v1/parks?api_key=UM1h28u00KVzbF5neRU0YLzt3Cb48nCf1PTBJWvJ&statecode=nj


Once a call to the API is made, Adalo gives us the options to fetch any specific variable from the list of all variables that the API call has, for example, in our demo, we chose to display variables such as, “fullName”, “description”, etc.