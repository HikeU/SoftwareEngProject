﻿Please follow the following steps In order to test/run the app:


Step 1:Download and setup Android Studio
* Please visit the following link for instructions on how to download Android studio: https://developer.android.com/studio/install


Step 2:  Open Android Studio


Step 3:  Go to the home page


Step 4:  Click “file” on the top left corner of Android studio


Step 5:  Click “Profile or debug APK” 
            -A window allowing you to choose a file will pop up


Step 6:  Select the hikeU .apk file that was provided by us


Step 7:  Click “Ok”


Step 8:  Connect a device that has an Android operating system to the computer being used to                                   test the code


Step 9:  Chose the device that you want to run/test the app on Android studios


Step 10:Click “Run app” on the top bar of Android Studios
-The App will be loaded to your phone
-The app will open on your android phone and you will be able to test it