﻿Integration Testing:


The Integration Test can be run using two methods:


1. Download the apk file and run the project using Android Studio or by loading the app onto an Android device. In order to use Android Studio, please refer to README1, where we explain how to run our project code using Android Studio software.


OR


2. Use the Adalo preview link to run the app on any device: https://previewer.adalo.com/dd24fd55-6dcd-42c4-80ad-03b7b88b940e