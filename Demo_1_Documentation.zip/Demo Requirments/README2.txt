﻿In order to test every feature that was completed by different subprojects, do the following for the different subprojects:


Park Search:
Follow the following steps to test the park search functionality


Step 1: Open the following preview link ( a link that allows you to view our search functionality by itself)
                Link: https://previewer.adalo.com/b6242ac6-2b2f-44fe-bd00-ffac57e6753e


Step 2:  Enter the two letter abbreviation of any state ( use NJ as an example)


Step 3: Click the “Search” button on the bottom
* A list of parks and pictures will be displayed


Step 4: Click the “+” sign shown on the right hand side of any park that you like 
* A description of the park will be displayed
* The parks contact information will be displayed if applicable


Step 5: Click the backward arrow sign on the top left corner of the application


You can either repeat Step 4 with a different park or reclick the backward arrow sign on the top left corner of the application and redo steps 1-4 with different parameters.


--
Park Alerts:
Follow the following steps to test the park search functionality


Step 1: Open the following preview link ( a link that allows you to view our search functionality by itself)
                Link: https://previewer.adalo.com/965aa2f3-dbfa-41c3-a673-e28065d770d2


Step 2: Select a state from the dropdown menu


Step 3: Click the green “Search” button
* A list of parks will be displayed


Step 4: Click the “+” sign shown on the right hand side of an alert
* A full description of the selected alert will be displayed


Step 5: Click the backward arrow sign on the top left corner of the application


The user can either repeat Step 4 with a different alert or click the backward arrow again to return to the park selection screen.


--
Social Media:
Follow the following steps to test the park search functionality


Step 1: Open the following preview link (a link that allows you to view our social media functionality by itself)
                Link:: https://previewer.adalo.com/4692faa4-ed24-4d58-8df7-1922344f846d


Step 2: If you already have an account click on “Already have an Account ? in the bottom and fill in your Username/Password and click on the “Login” button.


Step 3: If you don’t have an account, fill in the credentials and click on the “Sign Up” button.


Step 4: Follow Parks by clicking on the + icon that says “Follow”.


Step 5: View the posts related to the parks you are following by clicking on the home icon that says “Feed”.


Step 6: Create a Post by clicking on the Camera icon that says “Post”.


Step 7: View/Edit your Profile & Posts  by clicking on the User icon that says “Profile”.


Step 8: Click on the arrow icon on the top right corner in the “Feed” tab in order to logout.


--
Route Tracker/Planner


Testing for this functionality is currently not available